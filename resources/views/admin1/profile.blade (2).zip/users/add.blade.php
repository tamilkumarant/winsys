@extends('admin.layout')

@section('css')
<style>

</style>

@endsection

@section('content')
		
        <!-- Content Header (Page header) -->
			
        <section class="content-header">	
			<h1>
				Users
			</h1>
			<ol class="breadcrumb">
				<li class="active"></li>	
			</ol>
        </section>
		<section class="content">
			<div class="row">
				<!-- left column -->
				<div class="col-md-12">	
				
					@if(Session::has('success_msg'))
					<div class="box callout callout-success">
						<div class="box-header ">
							{{Session::get('success_msg')}}
							<div class="box-tools pull-right">
								<button class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove"><i class="fa fa-times"></i></button>
							</div>
						</div>
					</div><!-- /.box -->	
					@endif
					@if(Session::has('error_msg'))
					<div class="box callout callout-danger">
						<div class="box-header ">
							{{Session::get('error_msg')}}
							<div class="box-tools pull-right">
								<button class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove"><i class="fa fa-times"></i></button>
							</div>
						</div>
					</div>
					@endif
				
				  <!-- general form elements -->
					<div class="box box-primary">
						<div class="box-header with-border" style="padding-top:10px; padding-bottom:10px; padding-left:10px;">
							<h3 class="box-title">Add User</h3>
						</div>
						
						<form role="form" class="validate" method="post" action="">
							<input type="hidden" name="_token" value="{{ csrf_token() }}">
							
							<div class="container" style="padding-top:10px;">
								<div class='col-md-2'>
								   <label for="name">Name</label><span class="required_star">*</span>
								</div>
								<div class='col-md-4'>
									<input type="text" class="form-control" id="name" name="name" placeholder="Name" required/>
								</div>
							</div>
							
							<div class="container" style="padding-top:10px;">
								<div class='col-md-2'>
								   <label for="username">Username</label><span class="required_star">*</span>
								</div>
								<div class='col-md-4'>
									<input type="text" class="form-control" id="username" name="username" placeholder="Username" required/>
								</div>
							</div>
							
							<div class="container" style="padding-top:10px;">
								<div class='col-md-2'>
								   <label for="password_text">Password</label><span class="required_star">*</span>
								</div>
								<div class='col-md-4'>
									<input type="text" class="form-control" id="password_text" name="password_text" placeholder="Password" required/>
								</div>
							</div>
							
							<div class="container" style="padding-top:10px;">
								<div class='col-md-2'>
								   <label for="mobile">Mobile</label><span class="required_star">*</span>
								</div>
								<div class='col-md-4'>
									<input type="number" class="form-control" id="mobile" name="mobile" placeholder="Mobile" required/>
								</div>
							</div>
							
							<div class="container" style="padding-top:10px;">
								<div class='col-md-2'>
								   <label for="email">E-mail</label><span class="required_star">*</span>
								</div>
								<div class='col-md-4'>
									<input type="email" class="form-control" id="email" name="email" placeholder="E-mail" required/>
								</div>
							</div>
							
							<div class="container" style="padding-top:10px;">
								<div class='col-md-2'>
								   <label for="user_role"> User Role</label><span class="required_star">*</span>
								</div>
								<div class='col-md-4'>
									<select name="user_role" class="form-control user_role" required >
											<option value="">Select User Role</option>
											@foreach($roles as $key=>$val)
												<option value="{{$val->id}}" >{{$val->name}}</option>
											@endforeach
									</select>
								</div>
							</div>
							
							
							<div class="container" style="padding-top:10px;">
								<div class='col-md-2'>
								   <label>Stations<span class="required_star">*</span></label>
								</div>
								<div class='col-md-4'>
									<select class="form-control select2 station" multiple="multiple" name="station[]" data-placeholder="Select a Stations" style="width: 100%;" required>
											@foreach($station as $key=>$val)
												<option value="{{$val->id}}" >{{$val->station_name}}</option>
											@endforeach
										</select>
									<div><label for="station[]" generated="true" class="error"></label></div>
								</div>
							</div>
							
							<div class="container" style="padding-top:10px;">
							   <div class='col-md-2'>
									<label></label>
							  </div>
							  <div class='col-md-2'style="padding-top:10px;">
								  <button type="submit" value="Submit"  style="width:100px;" class="btn btn-primary ">Submit</button>
							  </div>
							  <div class='col-md-2'style="padding-top:10px;">
								  <a href="{{URL::to('user')}}"><button type="button" style="width:100px;" class="btn btn-primary active">Cancel</button></a>
							  </div>
							</div>
							
						</form>
					</div><!-- /.box -->
				</div>
			</div>
		</section>


        <!-- Main content -->
        

@endsection

@section('js')

<script>
	$(document).ready(function () {
		$('.validate').validate();
		$(".select2").select2();
	});
</script>

@endsection

